<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted Access');

jimport('joomla.application.component.helper'); // Import component helper library
$params = JComponentHelper::getParams(JRequest::getVar('option')); // Get parameter helper (corrected 'JRquest' spelling)
echo $params->get('mail'); // Get an individual parameter

$url = JUri::getInstance(); 
$document = JFactory::getDocument();
$document->addScriptOptions('com_ortana', [
  'assets' => JUri::base() . 'components/com_ortana/app/assets/',
  'ajax_url' => $url->toString()
]);

?>
<div ng-app="dashboardApp" ng-controller="dashboardCtrl">
  <div layout="row" layout-xs="column">
    <div style="width: 100%" ng-view></div>
  </div>
</div>
