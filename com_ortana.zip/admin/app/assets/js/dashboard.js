'use strict'
/* Variable global for module application */

var config = null;
var dashboard = angular.module('dashboardApp', [ 'ngRoute', 'ngMaterial' ]);
// self executing function here
(function() {
  config = Joomla.getOptions('com_ortana');
})();

