'use strict'
var dashboard = angular.module('dashboardApp', [ 'ngRoute', 'ngMaterial', 'ngMessages', 'routeDashboard' ]);
// self executing function here

