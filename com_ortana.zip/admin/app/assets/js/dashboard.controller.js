'use strict'

dashboard
  .controller('dashboardCtrl', ['$scope', 'dashboardFactory', function( $scope, dashboardFactory ) {
    $scope.articles = [];
    this.Initialize = function() {
      var Form = new FormData();
      Form.append('option', 'com_ajax');
      Form.append('plugin', 'tarifs');
      Form.append('method', 'gettarifs');
      Form.append('format', 'json');

      dashboardFactory.formHttp( Form )
        .then( function successCallback( results ) {
          var request = results.data;
          if (request.success)
            $scope.articles = request.data;
        })
    };
    this.Initialize();
  }])
  .factory('dashboardFactory', ["$http", "$q", function( $http, $q ) {
    return {
        /**
      * @param {FormData}
      * @return {Promise}
      */
      formHttp: function( form ) {
        return $http({
          url: config.ajax_url,
          method: "POST",
          headers: { 'Content-Type': undefined },
          data: form
        });
      }
    };
  }])
  .service('dashboardServices', [function() {

  }])
  .config(['$routeProvider', function( $routeProvider ) {
    $routeProvider
      .when('/dashboard', {
        templateUrl: config.assets + 'js/partials/dashboard.html',
        controller: 'dashboardCtrl'
      })
      .otherwise({
        redirectTo: '/dashboard'
      });
    
  }]);