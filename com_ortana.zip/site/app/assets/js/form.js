'use strict'
/* Application module */
var ortanaForm = angular.module("ortanaApp", [ "formRoute", "ngRoute", "ngMaterial", "ngSanitize", "ngMessages" ]);
