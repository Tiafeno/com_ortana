<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<h1><?= $this->msg; ?></h1>