<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
class OrtanaController extends JControllerLegacy
{
   
}